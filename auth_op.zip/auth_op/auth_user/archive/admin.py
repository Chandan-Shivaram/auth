from django.contrib import admin
from archive.models import user
# Register your models here.
@admin.register(user)
class StudentUser(admin.ModelAdmin):
    list_display=('name','usn','pin','email','password','check')
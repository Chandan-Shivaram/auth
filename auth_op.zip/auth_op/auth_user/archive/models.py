from django.db import models

# Create your models here.
class user(models.Model):
    name=models.CharField(null=True,blank=True,max_length=100)
    usn=models.CharField(max_length=100,primary_key=True,null=False)
    pin=models.IntegerField(blank=False,null=False)
    email=models.EmailField(max_length=100)
    password=models.CharField(max_length=20)
    Check=models.BooleanField(default=False)
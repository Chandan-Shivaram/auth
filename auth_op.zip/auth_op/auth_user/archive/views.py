from django.shortcuts import render
from archive.models import user
# Create your views here.
def signup(request):
    return render(request,'Asignup.html')
def Ainsert(request):
    ob=user()
    na=request.POST['name']
    ob.name=request.POST['name']
    ob.usn=request.POST['usn']
    ob.pin=request.POST['pin']
    ob.email=request.POST['email']
    ob.password=request.POST['pwd']
    ob.save()
    return render(request,'Anext.html',{'name':na})
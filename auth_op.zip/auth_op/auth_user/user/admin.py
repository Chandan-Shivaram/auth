from django.contrib import admin
from .models import deleted, user
# Register your models here.
@admin.register(user)
class StudentUser(admin.ModelAdmin):
    list_display=('name','usn','pin','email','password','check')
@admin.register(deleted)
class DeletedUser(admin.ModelAdmin):
    list_display=('name','usn','pin','email','date')
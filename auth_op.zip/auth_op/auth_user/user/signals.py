from django.db.models.signals import pre_delete,post_save
from .models import user,deleted
from django.dispatch import receiver
import datetime


@receiver(pre_delete,sender=user)
def create_table(sender, instance, **kwargs):

    
        d=deleted()
        d.name=instance.name
        d.usn=instance.usn
        d.email=instance.email
        d.pin=instance.pin
        d.date=datetime.datetime.now()
        d.save()
        print('Object inserted to deleted table')

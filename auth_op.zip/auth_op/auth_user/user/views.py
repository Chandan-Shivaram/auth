from asyncio.windows_events import NULL
import email
from django.shortcuts import render
from .models import user
from django.contrib.auth.models import User
from django.contrib.auth.hashers import check_password
from django.core.mail import send_mail
from django.views.generic.detail import DetailView
# Create your views here.

def home(request):
    return render(request,'index.html')

def signup(request):
    return render(request,'signup.html')

def signin(request):
    return render(request,'signin.html')

def asignin(request):
    return render(request,'asignin.html')


def insert(request):
    ob=user()
    na=request.POST['name']
    ob.name=request.POST['name']
    ob.usn=request.POST['usn']
    ob.pin=request.POST['pin']
    ob.email=request.POST['email']
    ob.password=request.POST['pwd']
    ob.save()
    return render(request,'next.html',{'name':na})



def check(request):
    pi=user.objects.get(pk=request.POST['usn'])
    if pi!=NULL and pi.password==request.POST['pwd']:
         return render(request,'next.html',{'data':pi})
    else:
         return render(request,'nouser.html')

def check1(request):
    ob=user.objects.all()
    ad=User.objects.get()
    if ad.email==request.POST['email'] and check_password(request.POST['pwd'],ad.password):
         return render(request,'admin.html',{'data':ob})
    else:
         return render(request,'nouser.html')

def update_data(request):
        ob=user.objects.all()
        pi=user.objects.get(pk=request.POST['id'])
        send_mail(
            'Congrats🎇 account verified',
            'Hi '+pi.name+' your account is verified \n Now you are active user.',
            'chandan.s@landmarkgroup.in',
            [pi.email],
        )
        pi.check=True
        pi.save()
        return render(request,'admin.html',{'data':ob})

def delete(request):
        ob=user.objects.all()
        pi=user.objects.get(pk=request.POST['id'])
        send_mail(
            'Sorry 😌 account rejected',
            'Hi '+pi.name+' your account got rejected \nPlease check the information and register again.',
            'chandan.s@landmarkgroup.in',
            [pi.email],
        )
        pi.delete()
        return render(request,'admin.html',{'data':ob})
